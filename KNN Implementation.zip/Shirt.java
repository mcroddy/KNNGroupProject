public class Shirt {
    int height;
    int weight;
    char size;


    public Shirt() {
        height = 0;
        weight = 0;
    }

    public Shirt (int h, int w) {
        height = h;
        weight = w;
    }

    public Shirt (int h, int w, char s) {
        height = h;
        weight = w;
        size = s;
    }

    public void setHeight(int h) { height = h; }
    public void setWeight(int w) { weight = w; }
    public void setSize(char s) { size = s; }

    public int getHeight() { return height; }
    public int getWeight() { return weight; }
    public char getSize() { return size; }

    public String toString() {
        return "H: " + height + "\tW: " + weight + "\tSize: " + size;
    }
}
