import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static final int k = 3;

    private static double distance(Shirt s1, Shirt s2) {
        int height = Math.abs(s1.getHeight() - s2.getHeight());
        int weight = Math.abs(s1.getWeight() - s2.getWeight());
        return Math.sqrt((height*height) + (weight*weight));
    }

    private static char knn(ArrayList<Shirt> L, Shirt s) {
        int n = L.size();
        if (n < k) {
            System.out.println("k larger than list length. ");
            return '0';
        }

        double[] d = new double[n];
        int[] ind = new int[n];
        for (int i=0; i<n; i++)
            ind[i] = i;

        // calculate all distances
        for (int i=0; i<n; i++)
            d[i] = distance(L.get(i), s);

        // selection sort for k minimum distances
        for (int i=0; i<k; i++) {
            int min_ind = i;
            for (int j=i+1; j<n; j++) { // to find next minimum
                if (d[j] < d[min_ind])
                    min_ind = j;
            }
            double temp = d[min_ind];
            d[min_ind] = d[i];
            d[i] = d[min_ind];
            int tempind = ind[min_ind];
            ind[min_ind] = ind[i];
            ind[i] = tempind;
        }

        // count frequency of classifications
        boolean[] visited = new boolean[k];
        int[] freq = new int[k];
        for (int i=0; i<k; i++) {
            if (visited[i])
                continue;
            int count = 1;
            for (int j=i+1; j<k; j++) {
                if (L.get(ind[i]).getSize() == L.get(ind[i]).getSize()) {
                    visited[j] = true;
                    count++;
                }
            }
            freq[i] = count;
        }

        // find max freq
        int max_ind = 0;
        for (int i=1; i<k; i++) {
            if (freq[i] > freq[max_ind])
                max_ind = i;
        }

        char newSize = L.get(ind[max_ind]).getSize();
        s.setSize(newSize);
        return newSize;
    }

    private static void print(ArrayList<Shirt> L) {
        for (int i=0; i<L.size(); i++) {
            System.out.println(L.get(i).toString());
        }
    }

    public static void main(String[] args) {
        ArrayList<Shirt> L = new ArrayList<Shirt>();
        L.add(new Shirt(158, 58, 'M'));
        L.add(new Shirt(158, 59, 'M'));
        L.add(new Shirt(158, 63, 'M'));
        L.add(new Shirt(160, 59, 'M'));
        L.add(new Shirt(163, 64, 'L'));
        L.add(new Shirt(169, 62, 'L'));
        L.add(new Shirt(170, 63, 'L'));
        L.add(new Shirt(153, 53, 'S'));
        L.add(new Shirt(155, 50, 'S'));
        L.add(new Shirt(150, 54, 'S'));

        Scanner in = new Scanner(System.in);
        int h, w;
        while (true) {
            System.out.print("Enter new customer height and weight, or 0 to quit: ");
            h = in.nextInt();
            if (h == 0) {
                System.out.println("Exiting program.");
                break;
            }
            else if (h == 1) {
                print(L);
                continue;
            }
            w = in.nextInt();
            Shirt a = new Shirt(h, w);
            char newSize = knn(L, a);
            System.out.println("Predicted shirt size: " + newSize);
            L.add(a);
        }

        System.out.print("Press Enter to close. ");
        in.nextLine();
        in.nextLine();
        in.close();
        return;
    }
}
